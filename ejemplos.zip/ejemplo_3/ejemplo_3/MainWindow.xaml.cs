﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ejemplo_3
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CrearGrid(object sender, RoutedEventArgs e)
        {
            int cols = int.Parse(tbColumnas.Text);
            int filas = int.Parse(tbFilas.Text);

            // Crear un grid de filas por cols (FILAS x COLS)
            Grid g = new Grid();

            // Crear las filas
            for(int i = 0; i < filas; i++)
            {
                g.RowDefinitions.Add(new RowDefinition());
            }

            // Crear las columnas
            for (int i = 0; i < cols; i++)
            {
                g.ColumnDefinitions.Add(new ColumnDefinition());
            }


            Random numRandom = new Random();
            // Crear filas por columnas rectángulos
           for (int i = 0; i < filas; i++) // filas
           {
                for (int j = 0; j < cols; j++) // columnas
                {


                    Rectangle r = new Rectangle();
                    //Color c = Color.FromRgb((byte)numRandom.Next(0, 255), (byte)numRandom.Next(0, 255), (byte)numRandom.Next(0, 255));
                    Color c = Color.FromRgb(255, 255, 255);
                    r.Fill = new SolidColorBrush(c);
                    //r.MouseEnter += CambiarColor;
                    r.MouseMove += CambiarColor;

                    Grid.SetRow(r,i);
                    Grid.SetColumn(r,j);

                    g.Children.Add(r);
                }
           }


            Grid.SetRow(g, 1); // se asigna la posicion para el grid "g" 
            gContenido.Children.Add(g);
        }

        private void CambiarColor(object sender, MouseEventArgs e)
        {
            if(e.LeftButton == MouseButtonState.Pressed)
            {
                // Cambiar Color rectangulo
                Rectangle r = (Rectangle)sender;

                Random numRandom = new Random();
                Color c = Color.FromRgb((byte)numRandom.Next(0, 255), (byte)numRandom.Next(0, 255), (byte)numRandom.Next(0, 255));
                //Color c = Color.FromRgb(1, 1, 1);
                r.Fill = new SolidColorBrush(c);
            }



        }
    }
}
