﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ejemplo_1_b
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Sólamente para poder acceder el metodo con el clase
        TextBox tb;
        Label l;
        public MainWindow()
        {
            InitializeComponent();

            StackPanel sp = new StackPanel();
            sp.Width = 300;

            // Creamos el textBox
            TextBox tb = new TextBox();

            // Creamos el button
            Button b = new Button();
            b.Content = "Copiar";
            b.Click += BottonCopiar;
            // Creamos label
            Label l = new Label();
            l.Content = "Etiqueta";

            sp.Children.Add(tb);
            sp.Children.Add(b);
            sp.Children.Add(l);
            ventana.Content = sp;
        }

        private void BottonCopiar(object sender, RoutedEventArgs e)
        {
            l.Content += tb.Text;
        }
    }
}
