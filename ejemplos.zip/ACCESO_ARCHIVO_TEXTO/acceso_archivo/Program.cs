﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace acceso_archivo
{
    class Program
    {
        static void Main(string[] args)
        {
            // WRITE LO QUE HAY EN EL ARCHIVO             // bin/Debug/prueba.txt
            /*using (StreamWriter sw = new StreamWriter("prueba.txt",true)) // true para añadir (no borrar lo que he escrito anterior) 
            {
                string linea = Console.ReadLine();
                sw.WriteLine(linea);
            }*/
            // READ LO QUE HAY EN EL ARCHIVO
            //----------------------------------------------------------------------------------------------------
            // Primera manera de hacer
            using (StreamReader sr = new StreamReader("prueba.txt")) // para leer que ha escrito
            {
                string linea = sr.ReadLine();

                while(linea != null)
                {
                    Console.WriteLine(linea);
                    linea = sr.ReadLine(); // cada vez que se ejecuta ReadLine() --> lee la siguiente linea
                }   
            }
            //----------------------------------------------------------------------------------------------------
            // Segunda manera de hacer
            using (StreamReader sr = new StreamReader("prueba.txt")) // para leer que ha escrito
            {
                string linea;

                while ((linea = sr.ReadLine()) != null)
                {
                    Console.WriteLine(linea);
                }
            }
            Console.ReadKey();
        }
    }
}
