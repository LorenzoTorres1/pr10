﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ejemplo_2
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Calcular(object sender, RoutedEventArgs e)
        {
            Button b = (Button)sender;

            int op1 = int.Parse(operador1.Text);
            int op2 = int.Parse(operador2.Text);
            int res = 0;
            if (b.Content.Equals("+"))
            {
                res = op1 + op2;
            }
            if (b.Content.Equals("-"))
            {
                res = op1 - op2;
            }
            if (b.Content.Equals("*"))
            {
                res = op1 * op2;
            }
            if (b.Content.Equals("/"))
            {
                res = op1 / op2;
            }
            resultado.Content = res;
        }
    }
}
